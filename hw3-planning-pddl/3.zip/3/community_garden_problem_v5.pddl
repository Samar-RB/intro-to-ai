(define (problem instance_5)

	(:domain communityGarden)

	(:objects
		cell0 cell1 cell2 cell3 cell4 cell5 cell6 cell7 cell8 cell9 cell10 cell11 cell12 cell13 cell14 cell15 cell16 cell17 cell18 cell19 cell20 cell21 cell22 cell23 cell24 cell25 cell26 cell27 cell28 cell29 cell30 cell31 cell32 cell33 cell34 cell35 cell36 cell37 cell38 cell39 cell40 cell41 cell42 cell43 cell44 cell45 cell46 cell47 - location
		volunteer1 volunteer2 volunteer3 - volunteer
		tiller1 - tiller
		seeds1 - seeds
		wateringCan1 - wateringCan
	)

	(:init
		(at volunteer1 cell33)
		(at volunteer2 cell9)
		(at volunteer3 cell39)
		(at tiller1 cell28)
		(at seeds1 cell2)
		(at wateringCan1 cell34)
		(is-cultivator volunteer1)
		(is-planter volunteer2)
		(is-waterer volunteer3)
	)

	(:goal
		(and
			(garden-is-thriving)
		)
	)
)